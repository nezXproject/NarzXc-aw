# Changelog

## 1.0.0
**Features**
- Tools: long-term memory, reminders (delivered back through the chat app), private files folder, calculator, clock; opt-in web search + page fetch
- Pairing codes: DM the bot, get a code, run `narzxclaw approve CODE`. No more hunting for numeric IDs
- Voice notes on Telegram, WhatsApp and Discord; multilingual speech-to-text by default; `narzxclaw voice-setup en|id` downloads a voice
- Personalities (`/mode lobster|captain|zen|pro`), auto language matching, `/memory`, `/forget`, `/help`
- `narzxclaw chat` (test in the terminal with no accounts), `export`, `wipe`, `--version`
- Docker Compose (Ollama + NarzXclaw) and `install.sh`
- Web app: quick-reply chips, typing indicator, reminder delivery

**Problems fixed from 0.1**
- Allowlist changes needed a restart → hot-reload from config.json
- Gateway token regenerated when it wasn't saved → persisted on first load
- Long replies were cut off by app limits → split per app (Telegram 4000, Discord 1900, Slack 3000)
- Whisper default was English-only → `small` multilingual
- Models without tool support crashed → automatic fallback to plain chat
- Missing model / Ollama down gave vague errors → specific, actionable messages
- WhatsApp `@lid` ids and reminders → jid map persisted by the bridge
- No flood protection → per-sender rate limit
- Web tools could reach your LAN → SSRF guard; file tools confined to a workspace folder
- Piper had to be installed by hand → `piper-tts` in the voice extra
