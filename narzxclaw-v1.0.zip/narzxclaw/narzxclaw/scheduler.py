import asyncio, time
from . import bus

async def run(store):
    """Delivers due reminders through whichever chat app the user set them from."""
    while True:
        await asyncio.sleep(15)
        for rid, ch, sender, text in store.due_reminders(time.time()):
            send = bus.SENDERS.get(ch)
            if not send: continue            # that app is offline right now; retry next tick
            try:
                await send(sender, f"⏰ Reminder: {text}")
                store.mark_done(rid)
            except Exception:
                pass
