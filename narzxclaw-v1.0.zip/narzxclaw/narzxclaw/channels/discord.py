import asyncio
import discord
from .. import bus, voice
from ..core import handle, allowed, chunk

async def run(cfg, brain):
    intents = discord.Intents.default()
    intents.message_content = True   # enable "Message Content Intent" in the Developer Portal
    client = discord.Client(intents=intents)

    async def send(uid, text):
        user = await client.fetch_user(int(uid))
        for part in chunk(text, 1900): await user.send(part)

    @client.event
    async def on_ready():
        bus.SENDERS["discord"] = send

    @client.event
    async def on_message(m):
        if m.author.bot: return
        is_dm = isinstance(m.channel, discord.DMChannel)
        if not (is_dm or client.user in m.mentions): return
        text = m.content.replace(f"<@{client.user.id}>", "").strip()
        async with m.channel.typing():
            clip = next((a for a in m.attachments if (a.content_type or "").startswith("audio")), None)
            if clip and voice.available(cfg) and allowed(cfg, "discord", m.author.id):
                text = await asyncio.to_thread(voice.transcribe, await clip.read(), cfg)
                await m.reply(f"🎙️ “{text}”")
            reply = await handle(cfg, brain, "discord", m.author.id, text)
        for part in chunk(reply, 1900):   # Discord's limit is 2000 characters
            await m.reply(part)

    await client.start(cfg["channels"]["discord"]["token"])
