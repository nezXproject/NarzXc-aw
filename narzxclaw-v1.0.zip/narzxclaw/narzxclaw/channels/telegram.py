import asyncio
from telegram.ext import Application, MessageHandler, filters
from .. import bus, voice
from ..core import handle, allowed, chunk

async def run(cfg, brain):
    app = Application.builder().token(cfg["channels"]["telegram"]["token"]).build()

    async def say(chat_id, text):
        for part in chunk(text, 4000):
            await app.bot.send_message(chat_id, part)

    async def on_text(update, ctx):
        await ctx.bot.send_chat_action(update.effective_chat.id, "typing")
        await say(update.effective_chat.id, await handle(cfg, brain, "telegram", update.effective_user.id, update.message.text))

    async def on_voice(update, ctx):
        uid, m = update.effective_user.id, update.message
        if not allowed(cfg, "telegram", uid) or not voice.available(cfg):
            return await say(m.chat_id, await handle(cfg, brain, "telegram", uid, "/help"))
        await ctx.bot.send_chat_action(m.chat_id, "typing")
        data = bytes(await (await (m.voice or m.audio).get_file()).download_as_bytearray())
        text = await asyncio.to_thread(voice.transcribe, data, cfg)
        await say(m.chat_id, f"🎙️ “{text}”\n\n" + await handle(cfg, brain, "telegram", uid, text))

    app.add_handler(MessageHandler(filters.TEXT, on_text))
    app.add_handler(MessageHandler(filters.VOICE | filters.AUDIO, on_voice))
    async with app:
        await app.start()
        await app.updater.start_polling()          # outbound only: no public URL needed
        bus.SENDERS["telegram"] = lambda uid, text: say(int(uid), text)
        await asyncio.Event().wait()
