import asyncio, os, shutil
from pathlib import Path
from .. import bus, config

BRIDGE = Path(__file__).resolve().parent.parent / "bridges" / "whatsapp"

def env(cfg):
    return {**os.environ, "GATEWAY_URL": f"http://127.0.0.1:{cfg['port']}", "GATEWAY_TOKEN": cfg["token"],
            "BRIDGE_PORT": str(cfg["port"] + 1), "AUTH_DIR": str(config.HOME / "whatsapp-auth")}

async def run(cfg, brain):
    """Runs the Baileys bridge as a child process; replies and reminders flow back through its local HTTP port."""
    import httpx
    if not shutil.which("node") or not (BRIDGE / "node_modules").exists():
        raise RuntimeError("WhatsApp bridge not installed: run `narzxclaw onboard` or `narzxclaw link whatsapp`")

    async def send(to, text):
        async with httpx.AsyncClient(timeout=20) as c:
            r = await c.post(f"http://127.0.0.1:{cfg['port'] + 1}/send", json={"to": to, "text": text},
                             headers={"authorization": f"Bearer {cfg['token']}"})
            r.raise_for_status()
    bus.SENDERS["whatsapp"] = send
    p = await asyncio.create_subprocess_exec("node", "index.js", cwd=BRIDGE, env=env(cfg))
    raise RuntimeError(f"WhatsApp bridge exited with code {await p.wait()}")
