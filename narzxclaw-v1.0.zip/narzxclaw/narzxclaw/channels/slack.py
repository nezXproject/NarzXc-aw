from slack_bolt.async_app import AsyncApp
from slack_bolt.adapter.socket_mode.async_handler import AsyncSocketModeHandler
from .. import bus
from ..core import handle, chunk

async def run(cfg, brain):
    c = cfg["channels"]["slack"]
    app = AsyncApp(token=c["bot_token"])

    @app.event("message")
    async def on_dm(event, say):
        if event.get("channel_type") != "im" or event.get("bot_id") or event.get("subtype"): return
        for part in chunk(await handle(cfg, brain, "slack", event["user"], event.get("text", "")), 3000):
            await say(part)

    @app.event("app_mention")
    async def on_mention(event, say):
        text = event.get("text", "").split(">", 1)[-1]
        for part in chunk(await handle(cfg, brain, "slack", event["user"], text), 3000):
            await say(part, thread_ts=event.get("ts"))

    async def send(uid, text):   # a user ID as the channel opens the app DM
        await app.client.chat_postMessage(channel=uid, text=text)
    bus.SENDERS["slack"] = send
    await AsyncSocketModeHandler(app, c["app_token"]).start_async()   # Socket Mode: no public URL
