import argparse, asyncio, json, os, platform, shutil, subprocess, sys
from pathlib import Path
import questionary
from rich.console import Console
from rich.panel import Panel
from . import __version__, config

console = Console()
BANNER = f"[bold red]🦞 NarzXclaw[/] [dim]v{__version__} · private · local · always on[/]"
VOICES = {"en": "en/en_US/lessac/medium/en_US-lessac-medium", "id": "id/id_ID/news_tts/medium/id_ID-news_tts-medium"}
PIPER_BASE = "https://huggingface.co/rhasspy/piper-voices/resolve/main/"

def ollama_models(cfg):
    try:
        import httpx
        return [m["name"] for m in httpx.get(f"{cfg['ollama_url']}/api/tags", timeout=3).json().get("models", [])]
    except Exception:
        return None

def ram_gb():
    try: return os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 2**30
    except (ValueError, OSError, AttributeError): return None

def recommend(ram):
    if ram is None: return "llama3.1:8b"
    return "llama3.2:3b" if ram < 8 else "llama3.1:8b" if ram < 20 else "qwen2.5:14b"

def ask_allow(label):
    v = questionary.text(f"{label} (optional: leave blank and just DM the bot; it will give you a pairing code)").ask() or ""
    return [x.strip() for x in v.split(",") if x.strip()]

def onboard(_):
    console.print(Panel(BANNER + f"\n\nLet's set up your lobster. Everything lives in [cyan]{config.HOME}[/] on this machine.", border_style="red"))
    cfg = config.load()
    cfg["owner"] = questionary.text("What should I call you?", default=cfg["owner"]).ask() or cfg["owner"]
    cfg["persona"] = questionary.select("Pick my personality", choices=["lobster", "captain", "zen", "pro"], default=cfg["persona"]).ask()
    lang = questionary.text("Reply language (blank = same language you write in)", default="").ask()
    cfg["language"] = lang.strip() or "auto"

    # Brain: recommend a model that fits this machine
    ram = ram_gb(); rec = recommend(ram)
    if ram: console.print(f"Detected ~{ram:.0f} GB RAM → I suggest [bold]{rec}[/].")
    models = ollama_models(cfg)
    if models is None:
        console.print("[yellow]Ollama isn't reachable. Install it from https://ollama.com and start it (you can finish this later).[/]")
        cfg["model"] = questionary.text("Model to use", default=rec).ask()
    else:
        pick = questionary.select("Which local model?", choices=models + [f"pull {rec} (recommended)", "pull another…"]).ask() if models else f"pull {rec} (recommended)"
        if pick.startswith("pull"):
            cfg["model"] = rec if "recommended" in pick else questionary.text("Model name to pull").ask()
            if shutil.which("ollama"): subprocess.run(["ollama", "pull", cfg["model"]])
        else:
            cfg["model"] = pick

    # Powers
    console.print("\n[bold]Powers[/]: memory, reminders and a private files folder are on. Web search sends queries to DuckDuckGo, so it is opt-in.")
    cfg["tools"]["web"] = bool(questionary.confirm("Enable web search + page fetching?", default=False).ask())

    # Chat apps
    chans = cfg["channels"]
    picked = questionary.checkbox("Which chat apps should I live in?", choices=["telegram", "discord", "slack", "whatsapp"]).ask() or []
    for name in chans: chans[name]["enabled"] = name in picked
    if "telegram" in picked:
        console.print("\n[bold]Telegram[/]: message @BotFather → /newbot → copy the token.")
        chans["telegram"]["token"] = questionary.password("Bot token").ask()
        chans["telegram"]["allow"] = ask_allow("Your Telegram user ID")
    if "discord" in picked:
        console.print("\n[bold]Discord[/]: discord.com/developers → New Application → Bot → copy token, enable [italic]Message Content Intent[/], invite the bot or DM it.")
        chans["discord"]["token"] = questionary.password("Bot token").ask()
        chans["discord"]["allow"] = ask_allow("Your Discord user ID")
    if "slack" in picked:
        console.print("\n[bold]Slack[/]: api.slack.com/apps → enable [italic]Socket Mode[/] (xapp- token) → bot scopes chat:write, im:history, im:write, app_mentions:read → events message.im + app_mention → install (xoxb- token) → App Home: enable Messages tab.")
        chans["slack"]["bot_token"] = questionary.password("Bot token (xoxb-…)").ask()
        chans["slack"]["app_token"] = questionary.password("App token (xapp-…)").ask()
        chans["slack"]["allow"] = ask_allow("Your Slack member ID")
    if "whatsapp" in picked:
        console.print("\n[bold]WhatsApp[/] links as a 'linked device' through an [yellow]unofficial[/] library; Meta can restrict accounts that do this, so consider a spare number.")
        chans["whatsapp"]["allow"] = ask_allow("Phone numbers allowed (digits with country code, no +)")
        bridge = Path(__file__).parent / "bridges" / "whatsapp"
        if shutil.which("npm") and questionary.confirm("Install the WhatsApp bridge now (npm install)?").ask():
            subprocess.run(["npm", "install", "--no-audit", "--no-fund"], cwd=bridge)
        elif not shutil.which("npm"):
            console.print("[yellow]Node.js 18+ not found. Install it, then run: narzxclaw link whatsapp[/]")

    # Voice
    if questionary.confirm("Enable voice (offline speech-to-text and text-to-speech)?", default=False).ask():
        cfg["voice"]["enabled"] = True
        console.print("Run [cyan]pip install 'narzxclaw[voice]'[/] then [cyan]narzxclaw voice-setup en|id[/] to download a voice.")

    config.save(cfg)
    console.print(Panel(
        "[green]Saved![/]\n\n1. Talk to me right now, no accounts needed: [bold]narzxclaw chat[/]\n"
        "2. Wake me up: [bold]narzxclaw run[/]   (DM your bot: it replies with a pairing code → [bold]narzxclaw approve CODE[/])\n"
        "3. Always on: [bold]narzxclaw service[/]\n"
        f"4. Phone: [bold]tailscale serve --bg {cfg['port']}[/], open the https URL, paste the token from [bold]narzxclaw token[/]\n"
        "5. Check health any time: [bold]narzxclaw doctor[/]", border_style="red"))
    if shutil.which("tailscale") and questionary.confirm(f"Run `tailscale serve --bg {cfg['port']}` now for phone access?", default=False).ask():
        subprocess.run(["tailscale", "serve", "--bg", str(cfg["port"])])

def run(_):
    from .runner import main as amain
    try:
        asyncio.run(amain(config.load()))
    except KeyboardInterrupt:
        console.print("🦞 Back to the tide pool. Bye!")

def chat(_):
    """Terminal chat with the same brain: the fastest way to test your setup."""
    from .brain import Brain
    from .core import handle
    cfg = config.load(); brain = Brain(cfg)
    console.print(BANNER + "\n[dim]Type /help for commands, Ctrl-C to quit.[/]")
    try:
        while True:
            line = console.input("[bold red]you ›[/] ").strip()
            if line: console.print("[bold]🦞 ›[/]", asyncio.run(handle(cfg, brain, "web", "me", line)))
    except (KeyboardInterrupt, EOFError):
        console.print("\n🦞 Bye!")

def doctor(_):
    cfg = config.load()
    ok = lambda b: "[green]✓[/]" if b else "[red]✗[/]"
    m = ollama_models(cfg)
    console.print(f"{ok(m is not None)} Ollama at {cfg['ollama_url']}")
    if m is not None: console.print(f"{ok(cfg['model'] in m)} model {cfg['model']} installed")
    console.print(f"{ok(True)} tools: " + ", ".join(k for k, v in cfg["tools"].items() if v) + (" [dim](web off = fully offline)[/]" if not cfg["tools"]["web"] else ""))
    for name, c in cfg["channels"].items():
        if not c["enabled"]: continue
        if name == "whatsapp": creds = (Path(__file__).parent / "bridges/whatsapp/node_modules").exists()
        else: creds = all(c.get(k) for k in ("token", "bot_token", "app_token") if k in c)
        console.print(f"{ok(creds)} {name}: credentials {'set' if creds else 'MISSING'}; {len(c['allow'])} approved sender(s) [dim](new people pair with a code)[/]")
    if cfg["voice"]["enabled"]:
        try:
            import faster_whisper  # noqa
            w = True
        except ImportError:
            w = False
        console.print(f"{ok(w)} faster-whisper   {ok(bool(shutil.which('piper')))} piper   {ok(bool(cfg['voice']['piper_model']))} voice model   [dim](whisper: {cfg['voice']['whisper_model']})[/]")

def approve(a):
    from .store import Store
    r = Store().resolve_pairing(a.code)
    if not r: sys.exit("Code not found or expired (codes last 1 hour). Ask them to message the bot again.")
    ch, sender = r
    cfg = config.load()
    if sender not in cfg["channels"][ch]["allow"]: cfg["channels"][ch]["allow"].append(sender)
    config.save(cfg)
    console.print(f"🦞 Approved {sender} on {ch}. Live immediately, no restart needed.")

def allow(a):
    cfg = config.load()
    if a.channel not in cfg["channels"]: sys.exit(f"channel must be one of {list(cfg['channels'])}")
    if a.id not in cfg["channels"][a.channel]["allow"]: cfg["channels"][a.channel]["allow"].append(a.id)
    config.save(cfg); console.print(f"🦞 {a.id} may talk to me on {a.channel}.")

def token(_):
    console.print(f"Gateway token: [bold]{config.load()['token']}[/]")

def link(a):
    from .channels.whatsapp import BRIDGE, env
    cfg = config.load()
    if not (BRIDGE / "node_modules").exists(): subprocess.run(["npm", "install", "--no-audit", "--no-fund"], cwd=BRIDGE)
    console.print("Scan the QR code, wait for 'WhatsApp connected', then Ctrl-C. Then use `narzxclaw run`.")
    subprocess.run(["node", "index.js"], cwd=BRIDGE, env=env(cfg))

def voice_setup(a):
    import httpx
    cfg = config.load(); d = config.HOME / "voices"; d.mkdir(parents=True, exist_ok=True)
    stem = VOICES[a.lang]; name = stem.split("/")[-1]
    for ext in (".onnx", ".onnx.json"):
        with httpx.stream("GET", PIPER_BASE + stem + ext, follow_redirects=True, timeout=120) as r:
            r.raise_for_status()
            with open(d / (name + ext), "wb") as f:
                for part in r.iter_bytes(): f.write(part)
    cfg["voice"].update(enabled=True, piper_model=str(d / (name + ".onnx")))
    config.save(cfg); console.print(f"🎙️ Voice ready: {name}")

def export(a):
    from .store import Store
    s = Store().db
    data = {t: s.execute(f"select * from {t}").fetchall() for t in ("msgs", "facts", "reminders")}
    Path(a.file).write_text(json.dumps(data, indent=2, ensure_ascii=False)); console.print(f"Exported to {a.file}")

def wipe(_):
    if questionary.confirm("Delete ALL memory (chats, facts, reminders)? This cannot be undone.", default=False).ask():
        (config.HOME / "memory.db").unlink(missing_ok=True); console.print("🦞 Memory wiped. Your data, your call.")

def service(_):
    exe = f"{sys.executable} -m narzxclaw run"; sysname = platform.system()
    if sysname == "Linux":
        p = Path.home() / ".config/systemd/user/narzxclaw.service"; p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(f"[Unit]\nDescription=NarzXclaw\nAfter=network-online.target\n\n[Service]\nExecStart={exe}\nRestart=always\nRestartSec=5\n\n[Install]\nWantedBy=default.target\n")
        console.print(f"Wrote {p}")
        if questionary.confirm("Enable and start it now?").ask():
            subprocess.run(["systemctl", "--user", "enable", "--now", "narzxclaw"])
            subprocess.run(["loginctl", "enable-linger", os.environ.get("USER", "")])
    elif sysname == "Darwin":
        p = Path.home() / "Library/LaunchAgents/dev.narzxclaw.plist"
        args = "".join(f"<string>{x}</string>" for x in exe.split())
        p.write_text('<?xml version="1.0" encoding="UTF-8"?><plist version="1.0"><dict><key>Label</key><string>dev.narzxclaw</string>'
                     f"<key>ProgramArguments</key><array>{args}</array><key>RunAtLoad</key><true/><key>KeepAlive</key><true/></dict></plist>")
        console.print(f"Wrote {p}")
        if questionary.confirm("Load it now?").ask(): subprocess.run(["launchctl", "load", str(p)])
    else:
        console.print(f"Windows: create a Task Scheduler task (at log on) that runs:\n  {exe}")

def main():
    ap = argparse.ArgumentParser(prog="narzxclaw", description="🦞 NarzXclaw: private, local personal AI assistant")
    ap.add_argument("--version", action="version", version=__version__)
    sub = ap.add_subparsers(dest="cmd")
    for n, f, h in [("onboard", onboard, "guided setup"), ("run", run, "start the assistant"), ("chat", chat, "talk to it in this terminal"),
                    ("doctor", doctor, "check everything"), ("token", token, "show phone/web token"),
                    ("service", service, "install as an always-on service"), ("wipe", wipe, "delete all memory")]:
        sub.add_parser(n, help=h).set_defaults(fn=f)
    p = sub.add_parser("approve", help="approve a pairing code"); p.add_argument("code"); p.set_defaults(fn=approve)
    p = sub.add_parser("allow", help="allow a sender by ID"); p.add_argument("channel"); p.add_argument("id"); p.set_defaults(fn=allow)
    p = sub.add_parser("link", help="link WhatsApp via QR"); p.add_argument("what", choices=["whatsapp"]); p.set_defaults(fn=link)
    p = sub.add_parser("voice-setup", help="download a Piper voice"); p.add_argument("lang", choices=list(VOICES)); p.set_defaults(fn=voice_setup)
    p = sub.add_parser("export", help="export memory to JSON"); p.add_argument("file", nargs="?", default="narzxclaw-export.json"); p.set_defaults(fn=export)
    args = ap.parse_args()
    if not args.cmd: console.print(BANNER); ap.print_help(); return
    args.fn(args)
