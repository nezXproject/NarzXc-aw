import json, os, secrets
from pathlib import Path

HOME = Path(os.environ.get("NARZXCLAW_HOME", Path.home() / ".narzxclaw"))
CONFIG = HOME / "config.json"

DEFAULTS = {
    "model": "llama3.1:8b",
    "ollama_url": "http://127.0.0.1:11434",
    "host": "127.0.0.1",          # loopback only; expose to your phone via Tailscale
    "port": 8787,
    "token": "",
    "owner": "",
    "persona": "lobster",         # lobster | captain | zen | pro
    "language": "auto",           # auto = reply in the language the user writes in
    "pairing": True,              # strangers get a pairing code instead of a dead end
    "rate_limit_per_min": 20,
    "tools": {"memory": True, "reminders": True, "files": True, "web": False},
    "channels": {
        "telegram": {"enabled": False, "token": "", "allow": []},
        "discord":  {"enabled": False, "token": "", "allow": []},
        "slack":    {"enabled": False, "bot_token": "", "app_token": "", "allow": []},
        "whatsapp": {"enabled": False, "allow": []},
    },
    "voice": {"enabled": False, "whisper_model": "small", "piper_model": ""},
}

def _merge(base, new):
    out = json.loads(json.dumps(base))
    for k, v in (new or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out

def load():
    data = json.loads(CONFIG.read_text()) if CONFIG.exists() else {}
    cfg = _merge(DEFAULTS, data)
    if os.environ.get("NARZXCLAW_HOST"): cfg["host"] = os.environ["NARZXCLAW_HOST"]
    if os.environ.get("NARZXCLAW_OLLAMA_URL"): cfg["ollama_url"] = os.environ["NARZXCLAW_OLLAMA_URL"]
    if not cfg["token"]:
        cfg["token"] = secrets.token_urlsafe(24)
        save(cfg)  # persist immediately: the token must not change between runs
    return cfg

def save(cfg):
    HOME.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text(json.dumps(cfg, indent=2))
    os.chmod(CONFIG, 0o600)  # holds bot tokens

_mtime = 0.0
def refresh(cfg):
    """Hot-reload allowlists/persona when config.json changes, so `approve` works without a restart."""
    global _mtime
    try:
        mt = CONFIG.stat().st_mtime
    except OSError:
        return
    if mt == _mtime:
        return
    _mtime = mt
    try:
        new = json.loads(CONFIG.read_text())
    except Exception:
        return
    for ch, c in cfg["channels"].items():
        c["allow"] = new.get("channels", {}).get(ch, {}).get("allow", c["allow"])
    for k in ("persona", "language", "pairing"):
        cfg[k] = new.get(k, cfg[k])
