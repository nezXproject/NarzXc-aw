"""Tools the assistant can call. Everything is local except web_search/fetch_url, which are opt-in."""
import ast, asyncio, datetime as dt, html, inspect, ipaddress, operator, re, socket, time
from urllib.parse import urlparse, parse_qs, unquote
from . import config

def _spec(name, desc, props=None, req=()):
    return {"type": "function", "function": {"name": name, "description": desc,
            "parameters": {"type": "object", "properties": props or {}, "required": list(req)}}}

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod, ast.USub: operator.neg}

def safe_eval(expr):
    """Arithmetic only: no names, no calls, no attribute access."""
    def ev(n):
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)): return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            a, b = ev(n.left), ev(n.right)
            if isinstance(n.op, ast.Pow) and abs(b) > 100: raise ValueError("exponent too large")
            return _OPS[type(n.op)](a, b)
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS: return _OPS[type(n.op)](ev(n.operand))
        raise ValueError("unsupported expression")
    return ev(ast.parse(expr.strip(), mode="eval").body)

def safe_path(rel):
    root = (config.HOME / "workspace").resolve(); root.mkdir(parents=True, exist_ok=True)
    p = (root / rel).resolve()
    if p != root and root not in p.parents: raise ValueError("path escapes the workspace folder")
    return p

def is_private_host(host):
    """SSRF guard: refuse loopback/LAN/link-local targets so the model can't be tricked into probing your network."""
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return True
    for i in infos:
        ip = ipaddress.ip_address(i[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
            return True
    return False

def _text(page):
    page = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", page)
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"(?s)<[^>]+>", " ", page))).strip()

class Tools:
    def __init__(self, cfg, store):
        self.cfg, self.store = cfg, store
        t = lambda g: cfg["tools"].get(g, False)
        R = {}
        def reg(group, spec, fn): R[spec["function"]["name"]] = (group, spec, fn)
        reg("core", _spec("get_time", "Get the current local date and time."), self.get_time)
        reg("core", _spec("calculate", "Evaluate an arithmetic expression exactly (+ - * / ** %).",
            {"expression": {"type": "string"}}, ["expression"]), self.calculate)
        if t("memory"):
            reg("memory", _spec("remember", "Save a durable fact about the user or their preferences for future chats.",
                {"fact": {"type": "string"}}, ["fact"]), self.remember)
            reg("memory", _spec("forget", "Delete a remembered fact by its numeric id.", {"id": {"type": "integer"}}, ["id"]), self.forget)
        if t("reminders"):
            reg("reminders", _spec("set_reminder", "Message the user later. Give either minutes (from now) or at (ISO local datetime like 2026-10-25T09:00).",
                {"text": {"type": "string"}, "minutes": {"type": "number"}, "at": {"type": "string"}}, ["text"]), self.set_reminder)
            reg("reminders", _spec("list_reminders", "List this user's pending reminders."), self.list_reminders)
        if t("files"):
            reg("files", _spec("list_files", "List files in the assistant's private workspace folder."), self.list_files)
            reg("files", _spec("read_file", "Read a text file from the workspace.", {"path": {"type": "string"}}, ["path"]), self.read_file)
            reg("files", _spec("write_file", "Create or overwrite a text file in the workspace.",
                {"path": {"type": "string"}, "content": {"type": "string"}}, ["path", "content"]), self.write_file)
        if t("web"):
            reg("web", _spec("web_search", "Search the web (DuckDuckGo). Use for current events or facts you don't know.",
                {"query": {"type": "string"}}, ["query"]), self.web_search)
            reg("web", _spec("fetch_url", "Download a public web page and return its text.", {"url": {"type": "string"}}, ["url"]), self.fetch_url)
        self.reg = R

    def specs(self): return [s for _, s, _ in self.reg.values()]

    async def call(self, name, args, ctx):
        if name not in self.reg: return f"error: unknown tool {name}"
        try:
            r = self.reg[name][2](args or {}, ctx)
            if inspect.isawaitable(r): r = await r
            return str(r)[:6000]
        except Exception as e:
            return f"error: {type(e).__name__}: {e}"

    # --- tools ---
    def get_time(self, a, ctx): return dt.datetime.now().astimezone().strftime("%A %Y-%m-%d %H:%M %Z")
    def calculate(self, a, ctx): return str(safe_eval(a["expression"]))
    def remember(self, a, ctx): return f"remembered as #{self.store.add_fact(a['fact'])}"
    def forget(self, a, ctx): return "forgotten" if self.store.forget(int(a["id"])) else "no such id"

    def set_reminder(self, a, ctx):
        if a.get("at"): due = dt.datetime.fromisoformat(a["at"]).timestamp()
        elif a.get("minutes") is not None: due = time.time() + float(a["minutes"]) * 60
        else: return "error: give minutes or at"
        if due < time.time() - 60: return "error: that time is in the past"
        rid = self.store.add_reminder(ctx["channel"], ctx["sender"], a["text"], due)
        return f"reminder #{rid} set for {dt.datetime.fromtimestamp(due):%Y-%m-%d %H:%M}"

    def list_reminders(self, a, ctx):
        rows = self.store.reminders(ctx["channel"], ctx["sender"])
        return "\n".join(f"#{i} {dt.datetime.fromtimestamp(d):%Y-%m-%d %H:%M} {t}" for i, t, d in rows) or "none"

    def list_files(self, a, ctx):
        root = safe_path(".")
        return "\n".join(str(p.relative_to(root)) for p in sorted(root.rglob("*")) if p.is_file()) or "(empty)"
    def read_file(self, a, ctx): return safe_path(a["path"]).read_text(errors="replace")[:6000]
    def write_file(self, a, ctx):
        p = safe_path(a["path"]); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(a["content"])
        return f"wrote {len(a['content'])} chars to {a['path']}"

    async def web_search(self, a, ctx):
        import httpx
        async with httpx.AsyncClient(timeout=15, headers={"User-Agent": "Mozilla/5.0 NarzXclaw"}) as c:
            page = (await c.post("https://html.duckduckgo.com/html/", data={"q": a["query"]})).text
        out = []
        for m in re.finditer(r'class="result__a" href="([^"]+)"[^>]*>(.*?)</a>.*?class="result__snippet"[^>]*>(.*?)</a>', page, re.S):
            link = m.group(1)
            if "uddg=" in link: link = unquote(parse_qs(urlparse(link).query)["uddg"][0])
            out.append(f"{_text(m.group(2))}\n{link}\n{_text(m.group(3))}")
            if len(out) == 5: break
        return "\n\n".join(out) or "no results"

    async def fetch_url(self, a, ctx):
        import httpx
        url = a["url"]
        async with httpx.AsyncClient(timeout=15, follow_redirects=False, headers={"User-Agent": "Mozilla/5.0 NarzXclaw"}) as c:
            for _ in range(4):
                u = urlparse(url)
                if u.scheme not in ("http", "https") or not u.hostname: return "error: only http(s) URLs"
                if await asyncio.to_thread(is_private_host, u.hostname): return "error: refusing to fetch private/local addresses"
                r = await c.get(url)
                if r.is_redirect: url = str(r.next_request.url); continue
                return _text(r.text)[:5000]
        return "error: too many redirects"
