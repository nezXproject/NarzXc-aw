# channel name -> async send(sender_id, text); channels register themselves when connected
SENDERS = {}
