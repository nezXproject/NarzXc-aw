// WhatsApp bridge (unofficial, via Baileys). Link once by scanning the QR code.
import http from 'node:http'
import fs from 'node:fs'
import makeWASocket, { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, downloadMediaMessage } from '@whiskeysockets/baileys'
import qrcode from 'qrcode-terminal'
import pino from 'pino'

const { GATEWAY_URL, GATEWAY_TOKEN, AUTH_DIR, BRIDGE_PORT } = process.env
const H = { authorization: `Bearer ${GATEWAY_TOKEN}` }
const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR)
const { version } = await fetchLatestBaileysVersion()

// sender id -> full jid (newer WhatsApp may use @lid ids, so we remember what each contact really is)
const jidFile = `${AUTH_DIR}/jids.json`
const jids = fs.existsSync(jidFile) ? JSON.parse(fs.readFileSync(jidFile, 'utf8')) : {}
let sock

http.createServer((req, res) => {  // lets the Python side push reminders out through WhatsApp
  if (req.method !== 'POST' || req.headers.authorization !== H.authorization) return res.writeHead(401).end()
  let b = ''; req.on('data', d => (b += d))
  req.on('end', async () => {
    try {
      const { to, text } = JSON.parse(b)
      await sock.sendMessage(jids[to] || `${to}@s.whatsapp.net`, { text })
      res.writeHead(200).end('ok')
    } catch (e) { res.writeHead(500).end(String(e)) }
  })
}).listen(Number(BRIDGE_PORT), '127.0.0.1')

async function ask(path, init) {
  const r = await fetch(`${GATEWAY_URL}${path}`, { method: 'POST', headers: H, ...init })
  return r.json()
}

async function start() {
  sock = makeWASocket({ auth: state, version, logger: pino({ level: 'silent' }) })
  sock.ev.on('creds.update', saveCreds)
  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr) { console.log('\n🦞 Scan with WhatsApp > Settings > Linked devices:\n'); qrcode.generate(qr, { small: true }) }
    if (connection === 'open') console.log('🦞 WhatsApp connected')
    if (connection === 'close') {
      if (lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut) {
        console.log('Logged out. Re-run: narzxclaw link whatsapp'); process.exit(1)
      }
      setTimeout(start, 3000)
    }
  })
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return
    for (const m of messages) {
      const jid = m.key.remoteJid
      if (!m.message || m.key.fromMe || !jid || jid.endsWith('@g.us') || jid === 'status@broadcast') continue
      const sender = jid.split('@')[0].split(':')[0]
      if (jids[sender] !== jid) { jids[sender] = jid; fs.writeFileSync(jidFile, JSON.stringify(jids)) }
      try {
        await sock.readMessages([m.key])
        await sock.sendPresenceUpdate('composing', jid)
        let out
        const text = m.message.conversation || m.message.extendedTextMessage?.text
        if (text) {
          out = await ask('/api/channel/whatsapp', { headers: { ...H, 'content-type': 'application/json' }, body: JSON.stringify({ sender, text }) })
        } else if (m.message.audioMessage) {   // voice note
          const fd = new FormData()
          fd.append('sender', sender)
          fd.append('audio', new Blob([await downloadMediaMessage(m, 'buffer', {})]), 'voice.ogg')
          out = await ask('/api/channel/whatsapp/audio', { body: fd })
          if (out.transcript) await sock.sendMessage(jid, { text: `🎙️ “${out.transcript}”` })
        }
        if (out?.reply) await sock.sendMessage(jid, { text: out.reply })
      } catch (e) { console.error('gateway error', e.message) }
    }
  })
}
start()
