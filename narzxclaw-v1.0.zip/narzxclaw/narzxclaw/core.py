import collections, time
from . import config

HELP = ("🦞 NarzXclaw\n/reset: wipe this chat's memory\n/mode lobster|captain|zen|pro: change my personality\n"
        "/memory: what I remember about you\n/forget <id>: delete a memory\n/help: this list")
_hits = collections.defaultdict(collections.deque)

def allowed(cfg, channel, sender):
    if channel == "web": return True   # already authenticated by the gateway token
    return str(sender) in [str(x) for x in cfg["channels"].get(channel, {}).get("allow", [])]

def rate_ok(cfg, session):
    q, now = _hits[session], time.time()
    while q and q[0] < now - 60: q.popleft()
    if len(q) >= cfg.get("rate_limit_per_min", 20): return False
    q.append(now); return True

def chunk(text, n=3800):
    """Split long replies on paragraph/line boundaries so they fit each app's message limit."""
    out = []
    while len(text) > n:
        cut = max(text.rfind("\n\n", 0, n), text.rfind("\n", 0, n), text.rfind(" ", 0, n))
        cut = cut if cut > n // 2 else n
        out.append(text[:cut].rstrip()); text = text[cut:].lstrip()
    return out + ([text] if text else [])

async def handle(cfg, brain, channel, sender, text):
    """Single entry point for every chat app."""
    config.refresh(cfg)
    st = brain.store
    if not allowed(cfg, channel, sender):
        code = st.create_pairing(channel, sender) if cfg.get("pairing", True) else None
        if code:
            return f"🦞 Hi! We haven't met. Pairing code: {code}\nAsk my owner to run:\nnarzxclaw approve {code}"
        return "🦞 *clicks claws* I only talk to people on my owner's list."
    text = (text or "").strip()
    if not text: return ""
    session = f"{channel}:{sender}"
    if not rate_ok(cfg, session): return "🦞 Whoa, too fast! Give me a minute to catch my breath."
    cmd, _, arg = text.partition(" ")
    cmd = cmd.lower()
    if cmd in ("/help", "/start"): return HELP
    if cmd in ("/reset", "/new"):
        brain.reset(session); return "🦞 Shell shed! Fresh start."
    if cmd == "/mode":
        from .persona import PERSONAS
        if arg.strip() not in PERSONAS: return "Modes: " + ", ".join(PERSONAS)
        st.set_pref(session, "persona", arg.strip()); return f"🦞 Mode: {arg.strip()}"
    if cmd == "/memory":
        return "\n".join(f"#{i} {t}" for i, t in st.facts()) or "I don't remember anything yet."
    if cmd == "/forget":
        return "Forgotten." if arg.strip().isdigit() and st.forget(int(arg)) else "Usage: /forget <id> (see /memory)"
    return await brain.reply(session, text, channel, sender)
