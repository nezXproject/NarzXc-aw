import datetime as dt
from .persona import system_prompt
from .store import Store
from .tools import Tools

MAX_STEPS = 5

class Brain:
    """Local LLM (Ollama) + persistent memory + a small tool loop. Nothing leaves the machine unless web tools are on."""
    def __init__(self, cfg):
        self.cfg, self.store = cfg, Store()
        self.tools = Tools(cfg, self.store)
        self.no_tools = False   # flips on if the chosen model can't do tool calling

    async def _chat(self, msgs, use_tools=True):
        import httpx
        body = {"model": self.cfg["model"], "messages": msgs, "stream": False}
        if use_tools and not self.no_tools: body["tools"] = self.tools.specs()
        async with httpx.AsyncClient(timeout=300) as c:
            r = await c.post(f"{self.cfg['ollama_url']}/api/chat", json=body)
            if r.status_code == 400 and "tools" in r.text and "tools" in body:
                self.no_tools = True               # model without tool support: degrade gracefully
                return await self._chat(msgs, use_tools=False)
            if r.status_code == 404:
                raise LookupError(f"model '{self.cfg['model']}' not found. Run: ollama pull {self.cfg['model']}")
            r.raise_for_status()
            return r.json()

    async def reply(self, session, text, channel="web", sender="me"):
        persona = self.store.pref(session, "persona", self.cfg.get("persona", "lobster"))
        now = dt.datetime.now().astimezone().strftime("%A %Y-%m-%d %H:%M %Z")
        msgs = [{"role": "system", "content": system_prompt(self.cfg, persona, self.store.search_facts(text), now)}]
        msgs += self.store.history(session) + [{"role": "user", "content": text}]
        ctx = {"channel": channel, "sender": sender}
        try:
            final = None
            for _ in range(MAX_STEPS):
                m = (await self._chat(msgs))["message"]
                calls = m.get("tool_calls") or []
                if not calls:
                    final = (m.get("content") or "").strip(); break
                msgs.append(m)
                for c in calls:
                    f = c["function"]
                    msgs.append({"role": "tool", "tool_name": f["name"], "content": await self.tools.call(f["name"], f.get("arguments"), ctx)})
            final = final or "🦞 I tied my claws in a knot on that one. Try rephrasing?"
        except LookupError as e:
            return f"🦞 {e}"
        except Exception as e:
            return f"🦞 My brain (Ollama) isn't answering ({type(e).__name__}). Is it running? Try `narzxclaw doctor`."
        self.store.add(session, "user", text)
        self.store.add(session, "assistant", final)
        return final

    def reset(self, session): self.store.reset(session)
