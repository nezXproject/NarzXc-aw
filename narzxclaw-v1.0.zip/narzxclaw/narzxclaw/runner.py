import asyncio, importlib
import uvicorn
from rich.console import Console
from . import __version__, scheduler
from .brain import Brain
from .gateway import build

console = Console()
CHANNELS = ["telegram", "discord", "slack", "whatsapp"]

async def supervise(name, factory):
    """Keep each chat app alive; one crashing never takes down the others."""
    delay = 5
    while True:
        try:
            await factory()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            console.print(f"[yellow]🦞 {name} dropped: {e}. Retrying in {delay}s[/]")
        await asyncio.sleep(delay)
        delay = min(delay * 2, 300)

async def main(cfg):
    brain = Brain(cfg)
    server = uvicorn.Server(uvicorn.Config(build(cfg, brain), host=cfg["host"], port=cfg["port"], log_level="warning"))
    tasks = [asyncio.create_task(server.serve()), asyncio.create_task(scheduler.run(brain.store))]
    for name in CHANNELS:
        if cfg["channels"][name]["enabled"]:
            mod = importlib.import_module(f"narzxclaw.channels.{name}")
            tasks.append(asyncio.create_task(supervise(name, lambda m=mod: m.run(cfg, brain))))
            console.print(f"🦞 {name} on")
    console.print(f"[bold]NarzXclaw v{__version__} is awake[/] → http://{cfg['host']}:{cfg['port']}  (model: {cfg['model']})")
    await asyncio.gather(*tasks)
