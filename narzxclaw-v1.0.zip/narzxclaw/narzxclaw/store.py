import secrets, sqlite3, time
from . import config

class Store:
    """All state in one local SQLite file: chat history, long-term facts, reminders, pairings, prefs."""
    def __init__(self):
        config.HOME.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(config.HOME / "memory.db", check_same_thread=False)
        self.db.executescript("""
        create table if not exists msgs(id integer primary key, session text, role text, content text, ts real);
        create table if not exists facts(id integer primary key, text text, ts real);
        create table if not exists reminders(id integer primary key, channel text, sender text, text text, due real, done integer default 0);
        create table if not exists pending(code text primary key, channel text, sender text, ts real);
        create table if not exists prefs(session text, key text, value text, primary key(session, key));
        """)
        self.db.commit()

    # chat history
    def add(self, session, role, content):
        self.db.execute("insert into msgs(session,role,content,ts) values(?,?,?,?)", (session, role, content, time.time()))
        self.db.commit()
    def history(self, session, n=24):
        rows = self.db.execute("select role,content from msgs where session=? order by id desc limit ?", (session, n)).fetchall()
        return [{"role": r, "content": c} for r, c in reversed(rows)]
    def reset(self, session):
        self.db.execute("delete from msgs where session=?", (session,)); self.db.commit()

    # long-term facts
    def add_fact(self, text):
        cur = self.db.execute("insert into facts(text,ts) values(?,?)", (text.strip(), time.time())); self.db.commit()
        return cur.lastrowid
    def facts(self):
        return self.db.execute("select id,text from facts order by id").fetchall()
    def forget(self, fid):
        n = self.db.execute("delete from facts where id=?", (fid,)).rowcount; self.db.commit(); return n
    def search_facts(self, q, n=6):
        words = [w.lower() for w in q.replace("?", " ").split() if len(w) > 2]
        scored = []
        for fid, text in self.facts():
            s = sum(w in text.lower() for w in words)
            if s: scored.append((s, fid, text))
        return [(i, t) for _, i, t in sorted(scored, reverse=True)[:n]]

    # reminders
    def add_reminder(self, channel, sender, text, due):
        cur = self.db.execute("insert into reminders(channel,sender,text,due) values(?,?,?,?)", (channel, str(sender), text, due))
        self.db.commit(); return cur.lastrowid
    def due_reminders(self, now):
        return self.db.execute("select id,channel,sender,text from reminders where done=0 and due<=?", (now,)).fetchall()
    def mark_done(self, rid):
        self.db.execute("update reminders set done=1 where id=?", (rid,)); self.db.commit()
    def reminders(self, channel, sender):
        return self.db.execute("select id,text,due from reminders where done=0 and channel=? and sender=? order by due", (channel, str(sender))).fetchall()

    # pairing: strangers get a code; the owner approves it from the terminal
    def create_pairing(self, channel, sender):
        self.db.execute("delete from pending where ts<?", (time.time() - 3600,))
        row = self.db.execute("select code from pending where channel=? and sender=?", (channel, str(sender))).fetchone()
        if row: return row[0]
        if self.db.execute("select count(*) from pending").fetchone()[0] >= 20: return None
        code = f"{secrets.randbelow(10**6):06d}"
        self.db.execute("insert into pending values(?,?,?,?)", (code, channel, str(sender), time.time())); self.db.commit()
        return code
    def resolve_pairing(self, code):
        row = self.db.execute("select channel,sender,ts from pending where code=?", (code.replace("-", "").strip(),)).fetchone()
        if not row or row[2] < time.time() - 3600: return None
        self.db.execute("delete from pending where code=?", (code.replace("-", "").strip(),)); self.db.commit()
        return row[0], row[1]

    # prefs
    def pref(self, session, key, default=None):
        r = self.db.execute("select value from prefs where session=? and key=?", (session, key)).fetchone()
        return r[0] if r else default
    def set_pref(self, session, key, value):
        self.db.execute("insert or replace into prefs values(?,?,?)", (session, key, value)); self.db.commit()
