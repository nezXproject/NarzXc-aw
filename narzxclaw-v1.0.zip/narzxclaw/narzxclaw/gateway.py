import asyncio, base64, hmac
from pathlib import Path
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from . import bus, voice
from .core import allowed, handle

WEB = Path(__file__).parent / "web"

def build(cfg, brain):
    app = FastAPI(title="NarzXclaw", docs_url=None, redoc_url=None)
    inbox = []   # reminders for the web app (no push channel, so it polls)

    async def to_web(sender, text): inbox.append(text)
    bus.SENDERS["web"] = to_web

    def auth(authorization):
        if not hmac.compare_digest((authorization or "").removeprefix("Bearer "), cfg["token"]):
            raise HTTPException(401, "bad token")

    class Msg(BaseModel): text: str
    class ChanMsg(BaseModel): sender: str; text: str

    @app.get("/")
    def index(): return FileResponse(WEB / "index.html")

    @app.get("/manifest.webmanifest")
    def manifest():
        return JSONResponse({"name": "NarzXclaw", "short_name": "NarzXclaw", "start_url": "/", "display": "standalone",
                             "background_color": "#0f1115", "theme_color": "#e8452c"})

    @app.get("/api/info")
    def info(authorization: str = Header("")):
        auth(authorization)
        return {"voice": voice.available(cfg), "model": cfg["model"], "persona": cfg["persona"]}

    @app.get("/api/inbox")
    def get_inbox(authorization: str = Header("")):
        auth(authorization)
        out = inbox[:]; inbox.clear(); return {"messages": out}

    @app.post("/api/chat")
    async def chat(m: Msg, authorization: str = Header("")):
        auth(authorization)
        return {"reply": await handle(cfg, brain, "web", "me", m.text)}

    async def _voice_turn(audio, channel, sender):
        if not voice.available(cfg): raise HTTPException(400, "voice is not enabled; run `narzxclaw onboard`")
        if not allowed(cfg, channel, sender):
            return {"transcript": "", "reply": await handle(cfg, brain, channel, sender, "/help")}
        text = await asyncio.to_thread(voice.transcribe, await audio.read(), cfg)
        if not text: return {"transcript": "", "reply": "🦞 I didn't catch that.", "audio": None}
        return {"transcript": text, "reply": await handle(cfg, brain, channel, sender, text)}

    @app.post("/api/voice")
    async def voice_web(audio: UploadFile = File(...), authorization: str = Header("")):
        auth(authorization)
        out = await _voice_turn(audio, "web", "me")
        try:
            out["audio"] = base64.b64encode(await asyncio.to_thread(voice.speak, out["reply"], cfg)).decode()
        except Exception:
            out["audio"] = None   # text-only fallback when Piper isn't configured
        return out

    @app.post("/api/channel/{channel}")
    async def channel(channel: str, m: ChanMsg, authorization: str = Header("")):
        auth(authorization)
        return {"reply": await handle(cfg, brain, channel, m.sender, m.text)}

    @app.post("/api/channel/{channel}/audio")
    async def channel_audio(channel: str, sender: str = Form(...), audio: UploadFile = File(...), authorization: str = Header("")):
        auth(authorization)
        return await _voice_turn(audio, channel, sender)

    return app
