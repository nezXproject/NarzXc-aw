import asyncio, os, tempfile, time, unittest
os.environ["NARZXCLAW_HOME"] = tempfile.mkdtemp()
from narzxclaw import config, core, tools
from narzxclaw.store import Store
from narzxclaw.brain import Brain

def run(c): return asyncio.run(c)

class T(unittest.TestCase):
    def setUp(self):
        self.cfg = config.load()
        self.cfg["channels"]["telegram"]["allow"] = ["1"]
        config.save(self.cfg); config._mtime = 0   # file is the source of truth for hot-reload
        core._hits.clear()
        self.brain = Brain(self.cfg)
        self.st = self.brain.store

    def test_token_persists(self):
        self.assertEqual(config.load()["token"], self.cfg["token"])

    def test_calc_safe(self):
        self.assertEqual(tools.safe_eval("2+3*4"), 14)
        for bad in ("__import__('os')", "2**1000", "open('x')", "a+1"):
            with self.assertRaises(Exception): tools.safe_eval(bad)

    def test_sandbox(self):
        tools.safe_path("notes/a.txt")
        for bad in ("../x", "/etc/passwd", "a/../../x"):
            with self.assertRaises(ValueError): tools.safe_path(bad)

    def test_ssrf(self):
        for h in ("127.0.0.1", "localhost", "192.168.1.5", "169.254.169.254", "10.0.0.1"):
            self.assertTrue(tools.is_private_host(h), h)

    def test_chunk(self):
        t = ("word " * 300).strip()
        parts = core.chunk(t, 200)
        self.assertTrue(all(len(p) <= 200 for p in parts))
        self.assertEqual(" ".join(parts).split(), t.split())

    def test_pairing_and_hot_reload(self):
        r = run(core.handle(self.cfg, self.brain, "telegram", "99", "hi"))
        code = r.split("Pairing code: ")[1][:6]
        self.assertEqual(self.st.resolve_pairing(code), ("telegram", "99"))
        self.assertIsNone(self.st.resolve_pairing(code))   # single use
        config.save({**self.cfg, "channels": {**self.cfg["channels"], "telegram": {**self.cfg["channels"]["telegram"], "allow": ["1", "99"]}}})
        core.config.refresh(self.cfg)
        self.assertTrue(core.allowed(self.cfg, "telegram", "99"))

    def test_commands_and_facts(self):
        fid = self.st.add_fact("Owner loves sambal")
        self.assertIn("sambal", run(core.handle(self.cfg, self.brain, "telegram", "1", "/memory")))
        self.assertEqual(self.st.search_facts("what about sambal?")[0][0], fid)
        run(core.handle(self.cfg, self.brain, "telegram", "1", f"/forget {fid}"))
        self.assertEqual(self.st.facts(), [])
        self.assertIn("zen", run(core.handle(self.cfg, self.brain, "telegram", "1", "/mode nope")))

    def test_rate_limit(self):
        self.cfg["rate_limit_per_min"] = 2
        res = [run(core.handle(self.cfg, self.brain, "telegram", "1", "/help")) for _ in range(3)]
        self.assertIn("too fast", res[2])

    def test_tool_loop(self):
        """Fake model: first asks for a tool, then answers using its result."""
        calls = []
        async def fake(msgs, use_tools=True):
            calls.append(msgs[-1]["role"])
            if msgs[-1]["role"] == "tool":
                return {"message": {"role": "assistant", "content": "It is " + msgs[-1]["content"]}}
            return {"message": {"role": "assistant", "content": "", "tool_calls": [
                {"function": {"name": "calculate", "arguments": {"expression": "6*7"}}}]}}
        self.brain._chat = fake
        self.assertEqual(run(self.brain.reply("t:1", "what is 6*7?")), "It is 42")

    def test_reminder_tool(self):
        out = run(self.brain.tools.call("set_reminder", {"text": "tea", "minutes": 0}, {"channel": "web", "sender": "me"}))
        self.assertIn("reminder #", out)
        self.assertEqual(self.st.due_reminders(time.time() + 1)[0][3], "tea")

    def test_file_tools(self):
        c = {"channel": "web", "sender": "me"}
        run(self.brain.tools.call("write_file", {"path": "a.txt", "content": "hi"}, c))
        self.assertEqual(run(self.brain.tools.call("read_file", {"path": "a.txt"}, c)), "hi")
        self.assertTrue(run(self.brain.tools.call("read_file", {"path": "../x"}, c)).startswith("error"))

    def test_web_tools_off_by_default(self):
        self.assertNotIn("web_search", self.brain.tools.reg)

if __name__ == "__main__":
    unittest.main()
