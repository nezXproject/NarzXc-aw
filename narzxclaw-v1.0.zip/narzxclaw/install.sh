#!/usr/bin/env sh
# One-command install: ./install.sh
set -e
python3 -c 'import sys; sys.exit(sys.version_info < (3, 10))' 2>/dev/null || { echo "Python 3.10+ is required."; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"
python3 -m venv "$HOME/.narzxclaw-venv"
"$HOME/.narzxclaw-venv/bin/pip" install -q -e "$SRC"
mkdir -p "$HOME/.local/bin"
ln -sf "$HOME/.narzxclaw-venv/bin/narzxclaw" "$HOME/.local/bin/narzxclaw"
echo "🦞 Installed. If 'narzxclaw' isn't found later, add ~/.local/bin to your PATH."
exec "$HOME/.local/bin/narzxclaw" onboard
