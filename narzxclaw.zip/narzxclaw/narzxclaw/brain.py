import sqlite3, time
import httpx
from . import config
from .persona import system_prompt

class Brain:
    """Local LLM via Ollama + SQLite conversation memory. Nothing leaves the machine."""
    def __init__(self, cfg):
        self.cfg = cfg
        config.HOME.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(config.HOME / "memory.db", check_same_thread=False)
        self.db.execute("create table if not exists msgs(id integer primary key, session text, role text, content text, ts real)")
        self.db.commit()

    def history(self, session, n=24):
        rows = self.db.execute("select role, content from msgs where session=? order by id desc limit ?", (session, n)).fetchall()
        return [{"role": r, "content": c} for r, c in reversed(rows)]

    def _save(self, session, role, content):
        self.db.execute("insert into msgs(session, role, content, ts) values(?,?,?,?)", (session, role, content, time.time()))
        self.db.commit()

    def reset(self, session):
        self.db.execute("delete from msgs where session=?", (session,))
        self.db.commit()

    async def reply(self, session, text):
        msgs = [{"role": "system", "content": system_prompt(self.cfg)}] + self.history(session) + [{"role": "user", "content": text}]
        try:
            async with httpx.AsyncClient(timeout=180) as c:
                r = await c.post(f"{self.cfg['ollama_url']}/api/chat",
                                 json={"model": self.cfg["model"], "messages": msgs, "stream": False})
                r.raise_for_status()
                out = r.json()["message"]["content"].strip()
        except Exception as e:
            return f"🦞 My brain (Ollama) isn't answering: {type(e).__name__}. Is it running? Try `narzxclaw doctor`."
        self._save(session, "user", text)
        self._save(session, "assistant", out)
        return out
