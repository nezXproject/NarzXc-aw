import asyncio, os, shutil
from pathlib import Path
from .. import config

BRIDGE = Path(__file__).resolve().parent.parent / "bridges" / "whatsapp"

def env(cfg):
    return {**os.environ,
            "GATEWAY_URL": f"http://127.0.0.1:{cfg['port']}",
            "GATEWAY_TOKEN": cfg["token"],
            "AUTH_DIR": str(config.HOME / "whatsapp-auth")}

async def run(cfg, brain):
    """Runs the Baileys bridge as a child process; it talks to the local gateway."""
    if not shutil.which("node") or not (BRIDGE / "node_modules").exists():
        raise RuntimeError("WhatsApp bridge not installed: run `narzxclaw onboard` or `npm install` in " + str(BRIDGE))
    p = await asyncio.create_subprocess_exec("node", "index.js", cwd=BRIDGE, env=env(cfg))
    code = await p.wait()
    raise RuntimeError(f"WhatsApp bridge exited with code {code}")
