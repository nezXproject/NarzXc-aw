from slack_bolt.async_app import AsyncApp
from slack_bolt.adapter.socket_mode.async_handler import AsyncSocketModeHandler
from ..core import handle

async def run(cfg, brain):
    c = cfg["channels"]["slack"]
    app = AsyncApp(token=c["bot_token"])

    @app.event("message")
    async def on_dm(event, say):
        if event.get("channel_type") != "im" or event.get("bot_id") or event.get("subtype"):
            return
        await say(await handle(cfg, brain, "slack", event["user"], event.get("text", "")))

    @app.event("app_mention")
    async def on_mention(event, say):
        text = event.get("text", "").split(">", 1)[-1]
        await say(await handle(cfg, brain, "slack", event["user"], text), thread_ts=event.get("ts"))

    await AsyncSocketModeHandler(app, c["app_token"]).start_async()  # Socket Mode: no public URL
