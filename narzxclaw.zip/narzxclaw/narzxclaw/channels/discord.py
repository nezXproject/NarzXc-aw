import discord
from ..core import handle

async def run(cfg, brain):
    intents = discord.Intents.default()
    intents.message_content = True  # enable "Message Content Intent" in the Developer Portal
    client = discord.Client(intents=intents)

    @client.event
    async def on_message(m):
        if m.author.bot:
            return
        is_dm = isinstance(m.channel, discord.DMChannel)
        if not (is_dm or client.user in m.mentions):
            return
        text = m.content.replace(f"<@{client.user.id}>", "").strip()
        async with m.channel.typing():
            reply = await handle(cfg, brain, "discord", m.author.id, text)
        for i in range(0, len(reply), 1900):   # Discord 2000-char limit
            await m.reply(reply[i:i + 1900])

    await client.start(cfg["channels"]["discord"]["token"])
