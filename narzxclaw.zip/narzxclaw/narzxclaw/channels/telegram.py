import asyncio
from telegram.ext import Application, MessageHandler, filters
from ..core import handle, allowed
from .. import voice

async def run(cfg, brain):
    app = Application.builder().token(cfg["channels"]["telegram"]["token"]).build()

    async def on_text(update, ctx):
        uid = update.effective_user.id
        await ctx.bot.send_chat_action(update.effective_chat.id, "typing")
        await update.message.reply_text(await handle(cfg, brain, "telegram", uid, update.message.text))

    async def on_voice(update, ctx):
        uid = update.effective_user.id
        if not allowed(cfg, "telegram", uid) or not voice.available(cfg):
            return await update.message.reply_text(await handle(cfg, brain, "telegram", uid, "hi"))
        f = await update.message.voice.get_file()
        data = bytes(await f.download_as_bytearray())
        text = await asyncio.to_thread(voice.transcribe, data, cfg)
        reply = await handle(cfg, brain, "telegram", uid, text)
        await update.message.reply_text(f"🎙️ \"{text}\"\n\n{reply}")

    app.add_handler(MessageHandler(filters.TEXT, on_text))
    app.add_handler(MessageHandler(filters.VOICE, on_voice))
    async with app:
        await app.start()
        await app.updater.start_polling()   # outbound only: no public URL needed
        await asyncio.Event().wait()
