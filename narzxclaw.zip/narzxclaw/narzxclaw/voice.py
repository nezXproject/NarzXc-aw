import re, subprocess, tempfile, os

_stt = None

def available(cfg):
    return cfg["voice"]["enabled"]

def transcribe(data: bytes, cfg) -> str:
    """Speech-to-text with faster-whisper, fully offline after the model is downloaded once."""
    global _stt
    from faster_whisper import WhisperModel
    if _stt is None:
        _stt = WhisperModel(cfg["voice"]["whisper_model"], compute_type="int8")
    with tempfile.NamedTemporaryFile(suffix=".audio") as f:
        f.write(data); f.flush()
        segs, _ = _stt.transcribe(f.name)
        return " ".join(s.text.strip() for s in segs).strip()

def _clean(text):
    text = re.sub(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]", "", text)
    return re.sub(r"[*_`#>]", "", text)

def speak(text: str, cfg) -> bytes:
    """Text-to-speech with Piper; returns WAV bytes."""
    model = cfg["voice"]["piper_model"]
    with tempfile.TemporaryDirectory() as d:
        out = os.path.join(d, "out.wav")
        subprocess.run(["piper", "--model", model, "--output_file", out],
                       input=_clean(text).encode(), check=True, capture_output=True)
        return open(out, "rb").read()
