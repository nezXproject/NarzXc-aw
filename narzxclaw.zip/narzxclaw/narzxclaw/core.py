def allowed(cfg, channel, sender):
    return str(sender) in [str(x) for x in cfg["channels"].get(channel, {}).get("allow", [])]

async def handle(cfg, brain, channel, sender, text):
    """Single entry point for every chat app. Unknown senders are refused."""
    if not allowed(cfg, channel, sender):
        return (f"🦞 *clicks claws* We haven't met! Ask my owner to run:\n"
                f"narzxclaw allow {channel} {sender}")
    text = (text or "").strip()
    if not text:
        return ""
    session = f"{channel}:{sender}"
    if text.lower() in ("/reset", "/new"):
        brain.reset(session)
        return "🦞 Shell shed! Fresh start."
    return await brain.reply(session, text)
