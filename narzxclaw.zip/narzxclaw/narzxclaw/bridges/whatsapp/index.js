// WhatsApp Web bridge (unofficial, via Baileys). Link once by scanning the QR code.
import makeWASocket, { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } from '@whiskeysockets/baileys'
import qrcode from 'qrcode-terminal'
import pino from 'pino'

const { GATEWAY_URL, GATEWAY_TOKEN, AUTH_DIR } = process.env
const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR)
const { version } = await fetchLatestBaileysVersion()

async function start() {
  const sock = makeWASocket({ auth: state, version, logger: pino({ level: 'silent' }) })
  sock.ev.on('creds.update', saveCreds)
  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr) { console.log('\n🦞 Scan with WhatsApp > Settings > Linked devices:\n'); qrcode.generate(qr, { small: true }) }
    if (connection === 'open') console.log('🦞 WhatsApp connected')
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode
      if (code === DisconnectReason.loggedOut) { console.log('Logged out. Re-run: narzxclaw link whatsapp'); process.exit(1) }
      start()
    }
  })
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return
    for (const m of messages) {
      const jid = m.key.remoteJid
      if (!m.message || m.key.fromMe || !jid || jid.endsWith('@g.us') || jid === 'status@broadcast') continue
      const text = m.message.conversation || m.message.extendedTextMessage?.text
      if (!text) continue
      const sender = jid.split('@')[0].split(':')[0]
      try {
        await sock.sendPresenceUpdate('composing', jid)
        const r = await fetch(`${GATEWAY_URL}/api/channel/whatsapp`, {
          method: 'POST',
          headers: { 'content-type': 'application/json', authorization: `Bearer ${GATEWAY_TOKEN}` },
          body: JSON.stringify({ sender, text }),
        })
        const { reply } = await r.json()
        if (reply) await sock.sendMessage(jid, { text: reply })
      } catch (e) { console.error('gateway error', e.message) }
    }
  })
}
start()
