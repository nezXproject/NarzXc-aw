import json, os, secrets
from pathlib import Path

HOME = Path(os.environ.get("NARZXCLAW_HOME", Path.home() / ".narzxclaw"))
CONFIG = HOME / "config.json"

DEFAULTS = {
    "model": "llama3.1:8b",
    "ollama_url": "http://127.0.0.1:11434",
    "host": "127.0.0.1",   # loopback only; expose to phone via Tailscale, see README
    "port": 8787,
    "token": "",
    "owner": "",
    "channels": {
        "telegram": {"enabled": False, "token": "", "allow": []},
        "discord":  {"enabled": False, "token": "", "allow": []},
        "slack":    {"enabled": False, "bot_token": "", "app_token": "", "allow": []},
        "whatsapp": {"enabled": False, "allow": []},
    },
    "voice": {"enabled": False, "whisper_model": "base.en", "piper_model": ""},
}

def _merge(base, new):
    out = json.loads(json.dumps(base))
    for k, v in (new or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out

def load():
    data = json.loads(CONFIG.read_text()) if CONFIG.exists() else {}
    cfg = _merge(DEFAULTS, data)
    if not cfg["token"]:
        cfg["token"] = secrets.token_urlsafe(24)
    return cfg

def save(cfg):
    HOME.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text(json.dumps(cfg, indent=2))
    os.chmod(CONFIG, 0o600)  # holds bot tokens
