import argparse, asyncio, os, platform, shutil, subprocess, sys
from pathlib import Path
import httpx, questionary
from rich.console import Console
from rich.panel import Panel
from . import config

console = Console()
BANNER = "[bold red]🦞 NarzXclaw[/] [dim]private · local · always on[/]"

def ollama_models(cfg):
    try:
        r = httpx.get(f"{cfg['ollama_url']}/api/tags", timeout=3)
        return [m["name"] for m in r.json().get("models", [])]
    except Exception:
        return None

def ask_allow(label, hint):
    v = questionary.text(f"{label} (comma-separated; {hint})").ask() or ""
    return [x.strip() for x in v.split(",") if x.strip()]

def onboard(_):
    console.print(Panel(BANNER + "\n\nLet's get your lobster set up. Everything is stored in "
                        f"[cyan]{config.HOME}[/] on this machine.", border_style="red"))
    cfg = config.load()
    cfg["owner"] = questionary.text("What should I call you?", default=cfg["owner"]).ask() or cfg["owner"]

    # 1. Brain
    models = ollama_models(cfg)
    if models is None:
        console.print("[yellow]Ollama isn't reachable. Install it from https://ollama.com and start it, then re-run onboard "
                      "(you can continue and finish this later).[/]")
        cfg["model"] = questionary.text("Model to use", default=cfg["model"]).ask()
    else:
        choices = models + ["(other: pull a new one)"]
        pick = questionary.select("Which local model?", choices=choices).ask() if models else "(other: pull a new one)"
        if pick.startswith("(other"):
            cfg["model"] = questionary.text("Model name to pull", default="llama3.1:8b").ask()
            if shutil.which("ollama") and questionary.confirm(f"Pull {cfg['model']} now?").ask():
                subprocess.run(["ollama", "pull", cfg["model"]])
        else:
            cfg["model"] = pick

    # 2. Chat apps
    chans = cfg["channels"]
    picked = questionary.checkbox("Which chat apps should I live in?",
        choices=["telegram", "discord", "slack", "whatsapp"]).ask() or []
    for name in chans:
        chans[name]["enabled"] = name in picked

    if "telegram" in picked:
        console.print("\n[bold]Telegram[/]: message @BotFather → /newbot → copy the token. Get your numeric ID from @userinfobot.")
        chans["telegram"]["token"] = questionary.password("Bot token").ask()
        chans["telegram"]["allow"] = ask_allow("Your Telegram user ID", "only these people can talk to me")
    if "discord" in picked:
        console.print("\n[bold]Discord[/]: discord.com/developers → New Application → Bot → copy token, and enable "
                      "[italic]Message Content Intent[/]. Invite the bot to a server (or just DM it). "
                      "User ID: Settings → Advanced → Developer Mode, then right-click yourself → Copy User ID.")
        chans["discord"]["token"] = questionary.password("Bot token").ask()
        chans["discord"]["allow"] = ask_allow("Your Discord user ID", "numeric")
    if "slack" in picked:
        console.print("\n[bold]Slack[/]: api.slack.com/apps → Create from scratch → enable [italic]Socket Mode[/] "
                      "(gives an xapp- token with connections:write) → add bot scopes chat:write, im:history, app_mentions:read "
                      "→ subscribe to events message.im and app_mention → install to workspace (xoxb- token). "
                      "Enable the App Home 'Messages' tab so you can DM it.")
        chans["slack"]["bot_token"] = questionary.password("Bot token (xoxb-…)").ask()
        chans["slack"]["app_token"] = questionary.password("App token (xapp-…)").ask()
        chans["slack"]["allow"] = ask_allow("Your Slack member ID", "profile → ⋮ → Copy member ID, e.g. U012ABC")
    if "whatsapp" in picked:
        console.print("\n[bold]WhatsApp[/]: links as a 'linked device' via an [yellow]unofficial[/] library. "
                      "Meta can restrict accounts that use these; consider a spare number.")
        chans["whatsapp"]["allow"] = ask_allow("Phone numbers allowed to message me", "digits with country code, no +, e.g. 6281234567890")
        bridge = Path(__file__).parent / "bridges" / "whatsapp"
        if shutil.which("npm"):
            if questionary.confirm("Install the WhatsApp bridge now (npm install)?").ask():
                subprocess.run(["npm", "install", "--no-audit", "--no-fund"], cwd=bridge)
        else:
            console.print("[yellow]Node.js not found. Install Node 18+, then run: narzxclaw link whatsapp[/]")

    # 3. Voice
    if questionary.confirm("Enable voice (offline speech-to-text + text-to-speech)?", default=False).ask():
        console.print("Needs: [cyan]pip install 'narzxclaw[voice]'[/] and Piper (https://github.com/rhasspy/piper) "
                      "with a voice model (.onnx).")
        cfg["voice"]["enabled"] = True
        cfg["voice"]["whisper_model"] = questionary.text("Whisper model", default=cfg["voice"]["whisper_model"]).ask()
        cfg["voice"]["piper_model"] = questionary.text("Path to Piper .onnx voice (blank = text replies only)",
                                                       default=cfg["voice"]["piper_model"]).ask()

    config.save(cfg)
    console.print(Panel(
        "[green]Saved![/]\n\n"
        "1. Start me:  [bold]narzxclaw run[/]\n"
        "2. Keep me always on:  [bold]narzxclaw service[/]\n"
        "3. Phone voice/chat: [bold]narzxclaw token[/] shows your token. Install Tailscale on this machine and your phone, then run\n"
        f"   [bold]tailscale serve --bg {cfg['port']}[/]  and open the https URL it prints, then 'Add to Home Screen'.\n"
        "4. Health check any time: [bold]narzxclaw doctor[/]", border_style="red"))

def run(_):
    from .runner import main as amain
    try:
        asyncio.run(amain(config.load()))
    except KeyboardInterrupt:
        console.print("🦞 Back to the tide pool. Bye!")

def doctor(_):
    cfg = config.load()
    ok = lambda b: "[green]✓[/]" if b else "[red]✗[/]"
    m = ollama_models(cfg)
    console.print(f"{ok(m is not None)} Ollama at {cfg['ollama_url']}")
    if m is not None:
        console.print(f"{ok(cfg['model'] in m)} model {cfg['model']} installed")
    for name, c in cfg["channels"].items():
        if c["enabled"]:
            creds = all(c.get(k) for k in ("token", "bot_token", "app_token") if k in c) if name != "whatsapp" else (Path(__file__).parent / "bridges/whatsapp/node_modules").exists()
            console.print(f"{ok(creds and c['allow'])} {name}: credentials {'set' if creds else 'MISSING'}, {len(c['allow'])} allowed sender(s)")
    if cfg["voice"]["enabled"]:
        try:
            import faster_whisper  # noqa
            w = True
        except ImportError:
            w = False
        console.print(f"{ok(w)} faster-whisper  {ok(bool(shutil.which('piper')))} piper  {ok(bool(cfg['voice']['piper_model']))} voice model")

def allow(a):
    cfg = config.load()
    if a.channel not in cfg["channels"]:
        sys.exit(f"unknown channel; choose from {list(cfg['channels'])}")
    lst = cfg["channels"][a.channel]["allow"]
    if a.id not in lst:
        lst.append(a.id)
    config.save(cfg)
    console.print(f"🦞 {a.id} may now talk to me on {a.channel}. Restart `narzxclaw run` to be safe.")

def token(_):
    cfg = config.load(); config.save(cfg)
    console.print(f"Gateway token: [bold]{cfg['token']}[/]")

def link(a):
    from .channels.whatsapp import BRIDGE, env
    cfg = config.load(); config.save(cfg)
    if not (BRIDGE / "node_modules").exists():
        subprocess.run(["npm", "install", "--no-audit", "--no-fund"], cwd=BRIDGE)
    console.print("Scan the QR code, wait for 'WhatsApp connected', then Ctrl-C. (Start `narzxclaw run` in another terminal so replies work.)")
    subprocess.run(["node", "index.js"], cwd=BRIDGE, env=env(cfg))

def service(_):
    exe = f"{sys.executable} -m narzxclaw run"
    sysname = platform.system()
    if sysname == "Linux":
        p = Path.home() / ".config/systemd/user/narzxclaw.service"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(f"[Unit]\nDescription=NarzXclaw\nAfter=network-online.target\n\n[Service]\nExecStart={exe}\n"
                     "Restart=always\nRestartSec=5\n\n[Install]\nWantedBy=default.target\n")
        console.print(f"Wrote {p}\nEnable it:\n  systemctl --user enable --now narzxclaw\n  loginctl enable-linger $USER   # keep running when logged out")
    elif sysname == "Darwin":
        p = Path.home() / "Library/LaunchAgents/dev.narzxclaw.plist"
        args = "".join(f"<string>{x}</string>" for x in exe.split())
        p.write_text('<?xml version="1.0" encoding="UTF-8"?><plist version="1.0"><dict>'
                     f"<key>Label</key><string>dev.narzxclaw</string><key>ProgramArguments</key><array>{args}</array>"
                     "<key>RunAtLoad</key><true/><key>KeepAlive</key><true/></dict></plist>")
        console.print(f"Wrote {p}\nLoad it:  launchctl load {p}")
    else:
        console.print(f"Windows: create a Task Scheduler task (trigger: at log on) that runs:\n  {exe}")

def main():
    ap = argparse.ArgumentParser(prog="narzxclaw", description="🦞 NarzXclaw: private, local personal AI assistant")
    sub = ap.add_subparsers(dest="cmd")
    for n, f, h in [("onboard", onboard, "guided setup"), ("run", run, "start the assistant"),
                    ("doctor", doctor, "check everything"), ("token", token, "show phone/web token"),
                    ("service", service, "install as an always-on background service")]:
        sub.add_parser(n, help=h).set_defaults(fn=f)
    a = sub.add_parser("allow", help="let someone talk to your assistant"); a.add_argument("channel"); a.add_argument("id"); a.set_defaults(fn=allow)
    l = sub.add_parser("link", help="link WhatsApp via QR"); l.add_argument("what", choices=["whatsapp"]); l.set_defaults(fn=link)
    args = ap.parse_args()
    if not args.cmd:
        console.print(BANNER); ap.print_help(); return
    args.fn(args)
