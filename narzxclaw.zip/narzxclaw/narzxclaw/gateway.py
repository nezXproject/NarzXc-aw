import asyncio, base64, hmac
from pathlib import Path
from fastapi import FastAPI, Header, HTTPException, UploadFile, File
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from .core import handle
from . import voice

WEB = Path(__file__).parent / "web"

def build(cfg, brain):
    app = FastAPI(title="NarzXclaw", docs_url=None, redoc_url=None)

    def auth(authorization: str):
        got = (authorization or "").removeprefix("Bearer ")
        if not hmac.compare_digest(got, cfg["token"]):
            raise HTTPException(401, "bad token")

    class Msg(BaseModel):
        text: str

    class ChanMsg(BaseModel):
        sender: str
        text: str

    @app.get("/")
    def index():
        return FileResponse(WEB / "index.html")

    @app.get("/manifest.webmanifest")
    def manifest():
        return JSONResponse({"name": "NarzXclaw", "short_name": "NarzXclaw", "start_url": "/",
                             "display": "standalone", "background_color": "#0f1115", "theme_color": "#e8452c"})

    @app.get("/api/info")
    def info(authorization: str = Header("")):
        auth(authorization)
        return {"voice": voice.available(cfg), "model": cfg["model"]}

    @app.post("/api/chat")
    async def chat(m: Msg, authorization: str = Header("")):
        auth(authorization)
        return {"reply": await brain.reply("web:me", m.text)}

    @app.post("/api/voice")
    async def voice_turn(audio: UploadFile = File(...), authorization: str = Header("")):
        auth(authorization)
        if not voice.available(cfg):
            raise HTTPException(400, "voice is not enabled; run `narzxclaw onboard`")
        text = await asyncio.to_thread(voice.transcribe, await audio.read(), cfg)
        if not text:
            return {"transcript": "", "reply": "🦞 I didn't catch that.", "audio": None}
        reply = await brain.reply("web:me", text)
        try:
            wav = await asyncio.to_thread(voice.speak, reply, cfg)
            b64 = base64.b64encode(wav).decode()
        except Exception:
            b64 = None  # text-only fallback if Piper isn't set up
        return {"transcript": text, "reply": reply, "audio": b64}

    @app.post("/api/channel/{channel}")
    async def channel(channel: str, m: ChanMsg, authorization: str = Header("")):
        auth(authorization)
        return {"reply": await handle(cfg, brain, channel, m.sender, m.text)}

    return app
